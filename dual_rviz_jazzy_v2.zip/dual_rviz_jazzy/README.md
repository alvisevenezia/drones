# dual_rviz_jazzy

Application Qt/RViz2 pour afficher deux vues 3D RViz indépendantes côte à côte.

- gauche : `/slam_map_vl53` en orange, Boxes 8 cm
- droite : `/cloud_map` en RGB8, Points 2 px
- Fixed Frame : `map`
- aucune modification des données ou TF

Cette version configure les displays directement en C++ et n'utilise pas
`rviz_common/config/reader.hpp`, qui n'est pas disponible sous cette forme
dans ROS 2 Jazzy.

## Compilation

```bash
source /opt/ros/jazzy/setup.bash
cd ~/Documents/drones
colcon build --packages-select dual_rviz_jazzy
source install/setup.bash
ros2 run dual_rviz_jazzy dual_rviz
```
