#include <memory>
#include <string>
#include <vector>
#include <QApplication>
#include <QHBoxLayout>
#include <QMainWindow>
#include <QVBoxLayout>
#include <QLabel>
#include <QWidget>

#include <rclcpp/rclcpp.hpp>
#include <ament_index_cpp/get_package_share_directory.hpp>
#include <rviz_common/render_panel.hpp>
#include <rviz_common/visualization_manager.hpp>
#include <rviz_common/ros_integration/ros_node_abstraction.hpp>
#include <rviz_common/window_manager_interface.hpp>
#include <rviz_common/display.hpp>
#include <rviz_common/visualization_manager.hpp>
#include <rviz_common/ros_integration/ros_node_abstraction.hpp>
#include <rviz_default_plugins/displays/grid/grid_display.hpp>
#include <rviz_default_plugins/displays/tf/tf_display.hpp>
#include <rviz_default_plugins/displays/pointcloud/point_cloud2_display.hpp>
#include <rviz_common/properties/ros_topic_property.hpp>


class DualRvizWindow : public QMainWindow
{
public:
  explicit DualRvizWindow(const std::shared_ptr<rviz_common::ros_integration::RosNodeAbstraction> & ros_node)
  : ros_node_(ros_node)
  {
    auto * central = new QWidget(this);
    auto * layout = new QHBoxLayout(central);
    layout->setContentsMargins(4, 4, 4, 4);
    layout->setSpacing(4);

    left_ = new rviz_common::RenderPanel();
    right_ = new rviz_common::RenderPanel();

    auto * left_box = new QWidget();
    auto * left_layout = new QVBoxLayout(left_box);
    left_layout->setContentsMargins(0,0,0,0);
    auto * left_label = new QLabel("Carte A — VL53 8x8");
    left_label->setAlignment(Qt::AlignCenter);
    left_layout->addWidget(left_label);
    left_layout->addWidget(left_);

    auto * right_box = new QWidget();
    auto * right_layout = new QVBoxLayout(right_box);
    right_layout->setContentsMargins(0,0,0,0);
    auto * right_label = new QLabel("Carte B — Camera RGB-D");
    right_label->setAlignment(Qt::AlignCenter);
    right_layout->addWidget(right_label);
    right_layout->addWidget(right_);

    layout->addWidget(left_box);
    layout->addWidget(right_box);
    setCentralWidget(central);

    setWindowTitle("Dual RViz — VL53 / RGB-D");
    resize(1500, 850);

    initPanel(left_, "vl53.rviz");
    initPanel(right_, "rgbd.rviz");
  }

private:
  void initPanel(
    rviz_common::RenderPanel * panel,
    bool vl53)
  {
    auto * manager = new rviz_common::VisualizationManager(
      panel,
      ros_node_,
      nullptr,
      ros_node_->get_raw_node()->get_clock());

    panel->initialize(manager);
    manager->initialize();
    manager->setFixedFrame("map");
    manager->startUpdate();

    auto * grid = manager->createDisplay<rviz_default_plugins::displays::GridDisplay>(
      "rviz_default_plugins/Grid", "Grid", true);
    grid->subProp("Plane Cell Count")->setValue(40);
    grid->subProp("Cell Size")->setValue(1.0);

    auto * tf = manager->createDisplay<rviz_default_plugins::displays::TFDisplay>(
      "rviz_default_plugins/TF", "TF", true);
    tf->subProp("Show Names")->setValue(true);
    tf->subProp("Marker Scale")->setValue(1.5);

    auto * cloud =
      manager->createDisplay<rviz_default_plugins::PointCloud2Display>(
        "rviz_default_plugins/PointCloud2", 
        vl53 ? "Carte A - VL53 8x8" : "Carte B - Camera RGB-D",
        true);

    auto * topic = cloud->subProp("Topic");
    topic->subProp("Topic")->setValue(
      vl53 ? "/slam_map_vl53" : "/cloud_map");

    if (vl53) {
      cloud->subProp("Style")->setValue("Boxes");
      cloud->subProp("Size (m)")->setValue(0.08);
      cloud->subProp("Color Transformer")->setValue("FlatColor");
      cloud->subProp("Color")->setValue(QColor(255, 120, 0));
    } else {
      cloud->subProp("Style")->setValue("Points");
      cloud->subProp("Size (Pixels)")->setValue(2);
      cloud->subProp("Color Transformer")->setValue("RGB8");
    }

    managers_.push_back(manager);
  }

  std::shared_ptr<rviz_common::ros_integration::RosNodeAbstraction> ros_node_;
  rviz_common::RenderPanel * left_{nullptr};
  rviz_common::RenderPanel * right_{nullptr};
  std::vector<rviz_common::VisualizationManager *> managers_;
};

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);

  QApplication app(argc, argv);

  auto ros_node =
    std::make_shared<rviz_common::ros_integration::RosNodeAbstraction>(
      "dual_rviz");

  DualRvizWindow window(ros_node);
  window.show();

  const int result = app.exec();
  rclcpp::shutdown();
  return result;
}
